package by.academy.homework6;

import java.util.Objects;

public class User {
	protected String Name;
	protected String Surname;
	protected int Year;

	public User() {
		super();
	}

	public User(String name, String surname, int year) {
		super();
		Name = name;
		Surname = surname;
		Year = year;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getSurname() {
		return Surname;
	}

	public void setSurname(String surname) {
		Surname = surname;
	}

	public int getYear() {
		return Year;
	}

	public void setYear(int year) {
		Year = year;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Name, Surname, Year);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		User other = (User) obj;
		return Objects.equals(Name, other.Name) && Objects.equals(Surname, other.Surname) && Year == other.Year;
	}

	@Override
	public String toString() {
		return "User [Name=" + Name + ", Surname=" + Surname + ", Year=" + Year + "]";
	}

}
