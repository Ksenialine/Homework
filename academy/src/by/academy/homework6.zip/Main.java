package by.academy.homework6;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

public class Main {
	public static void main(String[] args) {
		File file = new File("C:\\Bashlakova\\users\\");
		if (!file.exists()) {
			file.mkdirs();
		}

		ArrayList<User> users = new ArrayList<>();
		users.add(new User("John", "Smith", 23));
		users.add(new User("Nastya", "Brown", 25));
		users.add(new User("Sarah", "Davis", 40));
		users.add(new User("Kate", "Williams", 15));
		users.add(new User("Jane", "Morgan", 13));
		users.add(new User("Thomas", "Shelby", 37));
		users.add(new User("Oliver", "Gray", 59));
		users.add(new User("Ida", "Rivera", 22));
		users.add(new User("Ann", "Morris", 18));
		users.add(new User("Oscar", "Sanders", 30));

		for (User user : users) {
			File f = new File("C:\\Bashlakova\\users\\" + user.getName() + "_" + user.getSurname() + ".txt");
			try {
				if (!f.exists()) {
					f.createNewFile();
					f.mkdirs();
				}
			} catch (IOException e) {
				System.out.println(e.getMessage());
			}
			for (User user2 : users) {
				try (ObjectOutputStream oos = new ObjectOutputStream(
						new FileOutputStream(f))) {
					for (User user3 : users) {
						User i = new User();
						oos.writeObject(i);
					}
				} catch (Exception ex) {

					System.out.println(ex.getMessage());
				}
			}
		}
	}
}
