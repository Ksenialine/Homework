package by.academy.homework6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Task1 {
	public static void main(String[] args) throws IOException {
		String path = "C:" + File.separator + "Bashlakova" + File.separator + "Task1.txt";
		File f = new File(path);

		f.getParentFile().mkdirs();
		f.createNewFile();

		try (FileWriter writer = new FileWriter("C:\\Bashlakova\\Task1.txt");
				BufferedWriter bufferedWriter = new BufferedWriter(writer)) {

			Scanner scanner = new Scanner(System.in);
			System.out.println("Введите текст для загрузки в файл:");

			boolean stop = false;
			while (!stop) {

				String text1 = scanner.nextLine();

				if (text1.equals("stop")) {
					stop = true;
					break;
				}
				bufferedWriter.write(text1);
			}

			scanner.close();

		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
