package by.academy.homework6;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Proba {
	public static void main(String[] args) throws IOException {
		String path = "C:" + File.separator + "Bashlakova" + File.separator + "proba.txt";
		File f = new File(path);

		f.getParentFile().mkdirs();
		f.createNewFile();

		try (FileWriter writer = new FileWriter("C:\\Bashlakova\\proba.txt");
				BufferedWriter bufferedWriter = new BufferedWriter(writer)) {

			String text1 = "hello";

			bufferedWriter.write(text1);

		} catch (IOException ex) {
			System.out.println(ex.getMessage());
		}
	}
}
